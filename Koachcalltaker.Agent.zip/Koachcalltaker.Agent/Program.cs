using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;

namespace KoachCallTake;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // -------------------- Configuration --------------------
        // Load runtime-editable config files (no rebuild needed).
        // NOTE: reloadOnChange reloads IConfiguration, but we still re-bind per request below.
        builder.Configuration.AddJsonFile("agents.json", optional: false, reloadOnChange: true);
        builder.Configuration.AddJsonFile("companies.json", optional: false, reloadOnChange: true);
        builder.Configuration.AddJsonFile("prompts.json", optional: false, reloadOnChange: true);

        // -------------------- Services --------------------
        // Swagger
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();
        // Trip endpoints client (uses KoachApiService for auth)
        builder.Services.AddSingleton<KoachTripClient>();

        // HttpClientFactory (used for OpenAI + Koach API)
        builder.Services.AddHttpClient();

        // Koach Dispatch API wrapper service (handles JWT auth + caching)
        // IMPORTANT: This MUST be registered BEFORE builder.Build().
        builder.Services.AddSingleton<KoachApiService>();

        // -------------------- Build App --------------------
        var app = builder.Build();

        // -------------------- Middleware --------------------
        // Swagger (always on for now)
        app.UseSwagger();
        app.UseSwaggerUI();

        app.UseHttpsRedirection();

        // -------------------- Routes --------------------
        app.MapPost("/agent/message", async (
            // Request payload DTO
            [FromBody] AgentMessageRequest request,

            // Services
            [FromServices] IHttpClientFactory httpClientFactory,
            [FromServices] IConfiguration config,
            [FromServices] KoachApiService koachApiService,
            [FromServices] KoachTripClient koachTripClient,

            // Cancellation
            CancellationToken ct) =>
        {
            // -------------------- Input handling --------------------
            // For a call-taker, the first webhook/hit may be a "call connected" event.
            // In that case we may have routing context (extension/uid/callerPhone) but no spoken text yet.
            var userMessage = request.Message?.Trim() ?? "";

            // If we have no message, we still return a valid agent response (the greeting)
            // and a single next question to start the call.
            var isCallConnect = string.IsNullOrWhiteSpace(userMessage);

            // -------------------- OpenAI API key validation --------------------
            // API key from User Secrets or env var
            var apiKey = config["OpenAI:ApiKey"] ?? Environment.GetEnvironmentVariable("OPENAI_API_KEY");
            if (string.IsNullOrWhiteSpace(apiKey))
            {
                return Results.Problem(
                    "OpenAI API key is not configured. Set OpenAI:ApiKey (User Secrets) or OPENAI_API_KEY.",
                    statusCode: StatusCodes.Status500InternalServerError);
            }

            // -------------------- Load latest config per request --------------------
            // IMPORTANT: We bind per request so edits to JSON files are picked up without restarting.

            var currentAgents = new AgentsFile();
            config.GetSection("Agents").Bind(currentAgents.Agents);

            var currentCompanies = new CompaniesFile();
            config.GetSection("Companies").Bind(currentCompanies.Companies);

            if (currentCompanies.Companies == null || currentCompanies.Companies.Count == 0)
            {
                return Results.Problem(
                    "companies.json did not load correctly (0 companies). Check that the root is { \"Companies\": { ... } } and the file is copied to output.",
                    statusCode: StatusCodes.Status500InternalServerError);
            }

            // -------------------- Prompts (from prompts.json) --------------------
            // Bind per request so edits apply without restart.

            var currentPrompts = new PromptsFile();
            config.GetSection("Prompts").Bind(currentPrompts.Prompts);

            // Validate prompts.json loaded correctly.
            if (string.IsNullOrWhiteSpace(currentPrompts.Prompts.InitialCallTemplate) ||
                string.IsNullOrWhiteSpace(currentPrompts.Prompts.OngoingCallTemplate))
            {
                return Results.Problem(
                    "prompts.json did not load correctly (InitialCallTemplate or OngoingCallTemplate is empty). Check prompts.json format and ensure it's copied to output.",
                    statusCode: StatusCodes.Status500InternalServerError);
            }

            // -------------------- Company routing (from companies.json) --------------------
            var companyCfg = ResolveCompanyFromExtension(request.Extension, currentCompanies);
            if (companyCfg == null)
            {
                // Guardrail: don't let the model guess company
                return GuardrailUnknownCompany(request);
            }

            var company = companyCfg.CompanyName;

            // -------------------- Reservation lookup (stub for now) --------------------
            // Deterministic placeholder. Prevents the model from pretending it found a reservation.
            // -------------------- Reservation lookup (LIVE via Koach API) --------------------
            // Comment: Replace the old deterministic stub with a real dispatch API lookup by phone.
            // We do NOT let the model guess reservation data; we provide it deterministically as SYSTEM DATA.
            ReservationLookupResult reservationLookup;

            try
            {
                // Comment: base URL should be "https://apicall.koachapp.com"
                var baseUrl = config["Koach:ApiBaseUrl"] ?? "https://apicall.koachapp.com";

                // Comment: AgentEmail is used as the username for Koach API authentication.
                // We resolve it from agents.json using AgentUid.
                string agentEmail = "";
                if (!string.IsNullOrWhiteSpace(request.AgentUid) &&
                    currentAgents.Agents.TryGetValue(request.AgentUid, out var agentCfgForLookup))
                {
                    agentEmail = agentCfgForLookup.AgentEmail;
                }

                // Comment: Fail safe � if we cannot authenticate, we return "Found=false" with a clear note.
                if (string.IsNullOrWhiteSpace(agentEmail))
                {
                    reservationLookup = new ReservationLookupResult
                    {
                        Found = false,
                        Snapshot = null,
                        Note = "AgentEmail missing; reservation lookup skipped."
                    };
                }
                else if (string.IsNullOrWhiteSpace(request.CallerPhone))
                {
                    reservationLookup = new ReservationLookupResult
                    {
                        Found = false,
                        Snapshot = null,
                        Note = "CallerPhone missing; reservation lookup skipped."
                    };
                }
                else
                {
                    // Comment: Call the live Trip endpoint (GET).
                    var apiResult = await koachTripClient.GetLastReservationStatusByPhoneAsync(
                        baseUrl: baseUrl,
                        tenant: companyCfg.Tenant,
                        username: agentEmail,
                        phone: request.CallerPhone,
                        ct: ct
                    );

                    // Comment: If API failed, we keep Found=false and include the error.
                    if (!apiResult.Success)
                    {
                        reservationLookup = new ReservationLookupResult
                        {
                            Found = false,
                            Snapshot = null,
                            Note = $"Koach API lookup failed: {apiResult.Error}"
                        };
                    }
                    else
                    {
                        // Comment:
                        // SUCCESS means Koach returned a reservation record.
                        // We map it into the structure used by BuildSystemPrompt().
                        reservationLookup = new ReservationLookupResult
                        {
                            Found = true,
                            Snapshot = new ReservationSnapshot
                            {
                                ReservationId = apiResult.ReservationId ?? "",
                                Status = apiResult.Status ?? "",
                                Pickup = apiResult.Pickup ?? "",
                                Dropoff = apiResult.Dropoff ?? "",
                                ScheduledTime = apiResult.ScheduledTime ?? ""
                            },
                            Note = "Live lookup via Koach API: GetLastReservationStatusByPhone."
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                // Comment: Hard fallback to "not found" but preserve diagnostic note.
                reservationLookup = new ReservationLookupResult
                {
                    Found = false,
                    Snapshot = null,
                    Note = $"Reservation lookup exception: {ex.Message}"
                };
            }


            // -------------------- Agent identity (from agents.json) --------------------
            var agent = ResolveAgent(request.AgentUid, currentAgents);

            // -------------------- Koach Dispatch API Auth (JWT) --------------------
            // Authenticate the AI operator instance against Koach Dispatch API.
            //
            // Uses:
            // - Tenant from companyCfg (default "koach", DOB uses "DOB")
            // - AgentEmail from agents.json
            // - Shared password from User Secrets (Koach:AgentSharedPassword)
            //
            // The JWT is cached inside KoachApiService per (tenant + username).
            //
            // IMPORTANT:
            // - We NEVER return the JWT in the API response.
            // - We only return a boolean debug flag that says if it worked.
            string? koachJwt = null;
            string? koachAuthError = null;

            try
            {
                // Base URL comes from User Secrets or defaults to production API.
                var baseUrl = config["Koach:ApiBaseUrl"] ?? "https://apicall.koachapp.com";

                // Retrieve AgentEmail from agents.json using UID
                string agentEmail = "";
                if (!string.IsNullOrWhiteSpace(request.AgentUid) &&
                    currentAgents.Agents.TryGetValue(request.AgentUid, out var agentCfg))
                {
                    agentEmail = agentCfg.AgentEmail;
                }

                // Fail fast if AgentEmail is missing (prevents confusing auth errors)
                if (string.IsNullOrWhiteSpace(agentEmail))
                {
                    koachAuthError = "AgentEmail is missing for this AgentUid in agents.json.";
                }
                else
                {
                    // *** THIS WAS MISSING BEFORE ***
                    // Actually attempt to authenticate and get a JWT.
                    koachJwt = await koachApiService.GetJwtAsync(
                        baseUrl: baseUrl,
                        tenant: companyCfg.Tenant,
                        username: agentEmail,
                        ct: ct
                    );
                }
            }
            catch (Exception ex)
            {
                // IMPORTANT:
                // Do NOT hard-fail the whole /agent/message request if Koach auth fails.
                // The LLM can still answer general questions (or ask follow-ups),
                // but it will not be able to check ride status until Koach API works.
                koachAuthError = ex.Message;
            }
            // -------------------- Koach Trip Lookup (GetLastReservationStatusByPhone) --------------------
            // Comment: Now that JWT works, we test a real endpoint call using the same tenant + agentEmail.
            // We do NOT fail the request if this lookup fails; we return the error in debug output.
            KoachTripClient.KoachLastReservationStatusResult? lastTripByPhone = null;

            try
            {
                // Comment: Only attempt lookup if JWT succeeded and caller phone is present.
                if (!string.IsNullOrWhiteSpace(koachJwt) && !string.IsNullOrWhiteSpace(request.CallerPhone))
                {
                    var baseUrl = config["Koach:ApiBaseUrl"] ?? "https://apicall.koachapp.com";

                    // Comment: We already resolved agentEmail in the JWT block.
                    // If you kept it local there, re-resolve it here the same way.
                    string agentEmail = "";
                    if (!string.IsNullOrWhiteSpace(request.AgentUid) &&
                        currentAgents.Agents.TryGetValue(request.AgentUid, out var agentCfg2))
                    {
                        agentEmail = agentCfg2.AgentEmail;
                    }

                    if (!string.IsNullOrWhiteSpace(agentEmail))
                    {
                        lastTripByPhone = await koachTripClient.GetLastReservationStatusByPhoneAsync(
                            baseUrl: baseUrl,
                            tenant: companyCfg.Tenant,
                            username: agentEmail,
                            phone: request.CallerPhone!,
                            ct: ct
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                // Comment: Should not usually throw because KoachTripClient returns Error, but keep safe guard.
                lastTripByPhone = new KoachTripClient.KoachLastReservationStatusResult
                {
                    Success = false,
                    TenantId = companyCfg.Tenant ?? "",
                    Phone = request.CallerPhone ?? "",
                    Error = $"Trip lookup threw exception: {ex.Message}"
                };
            }

            // -------------------- Build prompt & call OpenAI --------------------
            // Build system prompt using dynamic company + agent + prompts.json rules + reservation lookup data.
            // If there is no caller message, this is the initial call connect.
            // Otherwise it is an ongoing turn.
            var systemPrompt = BuildSystemPrompt(
                companyCfg,
                agent,
                request.CallerPhone,
                currentPrompts.Prompts,
                reservationLookup,
                isCallConnect);

            // Model selection (request override > config > default)
            var model = request.Model ?? config["OpenAI:Model"] ?? "gpt-4o-mini";

            // Responses API payload
            var payload = new
            {
                model,
                input = new object[]
                {
                    new { role = "system", content = systemPrompt },

                    // If no spoken message yet, provide a minimal "call connected" user input
                    // so the model produces the greeting + next question.
                    new { role = "user", content = isCallConnect ? "Call connected. Begin the call." : userMessage }
                }
            };

            // Create OpenAI client via factory and apply auth header
            var client = httpClientFactory.CreateClient();
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

            using var content = new StringContent(
                JsonSerializer.Serialize(payload),
                Encoding.UTF8,
                "application/json");

            using var response = await client.PostAsync("https://api.openai.com/v1/responses", content, ct);
            var responseBody = await response.Content.ReadAsStringAsync(ct);

            if (!response.IsSuccessStatusCode)
            {
                return Results.Problem(
                    $"OpenAI API error: {(int)response.StatusCode} {response.ReasonPhrase}",
                    statusCode: (int)response.StatusCode,
                    extensions: new Dictionary<string, object?> { ["body"] = responseBody });
            }

            var extracted = ResponseHelper.ExtractResponseText(responseBody);

            // -------------------- Response --------------------
            // Debug routing info is included so we can verify:
            // - Company routing worked
            // - Agent identity resolved
            // - Koach JWT auth succeeded (without leaking token)
            return Results.Ok(new
            {
                response = extracted ?? responseBody,
                routing = new
                {
                    company,
                    extension_received = request.Extension,
                    caller_phone = request.CallerPhone,
                    agent_uid = request.AgentUid,
                    agent_alias = agent.Alias,
                    operator_number = agent.OperatorNumber,

                    // DEBUG: confirms Koach API authentication worked (without leaking the token)
                    koach_jwt_acquired = !string.IsNullOrWhiteSpace(koachJwt),

                    // DEBUG: safe error message for troubleshooting (does not include password or JWT)
                    koach_auth_error = koachAuthError,
                    koach_last_trip_by_phone = lastTripByPhone

                }
            });
        })
        .WithName("PostAgentMessage");

        // -------------------- Run --------------------
        app.Run();
    }

    // -------------------- Request/Config Types --------------------

    // Swagger request payload DTO
    // Message is optional because the first event may be a call-connect event with no spoken text yet.
    public record AgentMessageRequest(string? Message, string? Model, string? Extension, string? AgentUid, string? CallerPhone);

    // Resolved agent identity used to fill greeting placeholders
    public record AgentIdentity(string Uid, string Alias, string OperatorNumber);

    // agents.json root object
    public sealed class AgentsFile
    {
        public Dictionary<string, AgentConfig> Agents { get; set; } = new();
    }

    // agents.json value object (per agent UID)
    public sealed class AgentConfig
    {
        public string Alias { get; set; } = "Operator";
        public string OperatorNumber { get; set; } = "000";

        // Dispatch UID (stored as string for flexibility)
        public string Duid { get; set; } = "0";

        // Used to authenticate to Koach API (with shared password from secrets/env).
        public string AgentEmail { get; set; } = "";
    }

    // companies.json root object
    public sealed class CompaniesFile
    {
        public Dictionary<string, CompanyConfig> Companies { get; set; } = new();
    }

    // companies.json value object (per extension)
    public sealed class CompanyConfig
    {
        public string CompanyName { get; set; } = "Unknown";
        public string GreetingCompanyName { get; set; } = "your company";
        public string ServiceArea { get; set; } = "";

        // Dispatch API tenant. Default is "koach"; DOB uses "DOB".
        public string Tenant { get; set; } = "koach";
    }

    // prompts.json root object
    public sealed class PromptsFile
    {
        public PromptsConfig Prompts { get; set; } = new();
    }

    // prompts.json value object (per prompts section)
    public sealed class PromptsConfig
    {
        // Used when the call first connects (no caller message yet)
        public string InitialCallTemplate { get; set; } = "";

        // Used after the caller has spoken (message is present)
        public string OngoingCallTemplate { get; set; } = "";
    }

    // -------------------- Reservation Lookup (Stub for now) --------------------

    // Minimal reservation snapshot we can safely share with the model.
    public sealed class ReservationSnapshot
    {
        public string ReservationId { get; set; } = "";
        public string Status { get; set; } = "";
        public string Pickup { get; set; } = "";
        public string Dropoff { get; set; } = "";
        public string ScheduledTime { get; set; } = "";
    }

    // Result wrapper so we can explicitly represent "not found" vs "found".
    public sealed class ReservationLookupResult
    {
        public bool Found { get; set; }
        public ReservationSnapshot? Snapshot { get; set; }
        public string? Note { get; set; }
    }

    // STUB: Deterministic lookup placeholder.
    static ReservationLookupResult LookupActiveReservationByPhone(string? callerPhone, CompanyConfig companyCfg)
    {
        if (string.IsNullOrWhiteSpace(callerPhone))
        {
            return new ReservationLookupResult
            {
                Found = false,
                Snapshot = null,
                Note = "No caller phone provided; lookup skipped."
            };
        }

        return new ReservationLookupResult
        {
            Found = false,
            Snapshot = null,
            Note = "Stub lookup: not connected to dispatch system yet."
        };
    }

    // -------------------- Routing + Guardrails + Greetings --------------------

    // Takes an extension/huntgroup like "4100" or "(4100)" and returns only digits.
    static string NormalizeExtension(string? ext)
    {
        if (string.IsNullOrWhiteSpace(ext)) return "";
        return new string(ext.Where(char.IsDigit).ToArray());
    }

    // Looks up the company by extension in companies.json.
    static CompanyConfig? ResolveCompanyFromExtension(string? extension, CompaniesFile companiesFile)
    {
        var ext = NormalizeExtension(extension);

        if (string.IsNullOrWhiteSpace(ext))
            return null;

        if (companiesFile.Companies != null &&
            companiesFile.Companies.TryGetValue(ext, out var companyCfg))
        {
            return companyCfg;
        }

        return null;
    }

    // Looks up the agent by UID in agents.json.
    // If not found, returns Operator/000.
    static AgentIdentity ResolveAgent(string? agentUid, AgentsFile agentsFile)
    {
        var uid = (agentUid ?? "").Trim();

        if (string.IsNullOrWhiteSpace(uid))
            return new AgentIdentity("", "Operator", "000");

        if (agentsFile.Agents != null &&
            agentsFile.Agents.TryGetValue(uid, out var cfg) &&
            cfg != null)
        {
            return new AgentIdentity(uid, cfg.Alias ?? "Operator", cfg.OperatorNumber ?? "000");
        }

        return new AgentIdentity(uid, "Operator", "000");
    }

    // Replaces greeting placeholders with the resolved agent values.
    static string ApplyAgentToGreeting(string greetingTemplate, AgentIdentity agent)
    {
        return greetingTemplate
            .Replace("{ALIAS}", agent.Alias)
            .Replace("{OPNUM}", agent.OperatorNumber);
    }

    static string BuildSystemPrompt(
        CompanyConfig companyCfg,
        AgentIdentity agent,
        string? callerPhone,
        PromptsConfig prompts,
        ReservationLookupResult reservationLookup,
        bool isCallConnect)
    {
        var greetingTemplate =
            $"Thank you for calling {companyCfg.GreetingCompanyName}. My name is {{ALIAS}}, and my operator number is {{OPNUM}}. How may I assist you today?";

        var greeting = ApplyAgentToGreeting(greetingTemplate, agent);

        // Choose correct lifecycle template
        var baseRules = isCallConnect
            ? prompts.InitialCallTemplate
            : prompts.OngoingCallTemplate;

        // Safety fallback
        if (string.IsNullOrWhiteSpace(baseRules))
        {
            baseRules = "You are a professional taxi dispatch call taker. Be polite, concise, and professional. Ask ONE question at a time.";
        }

        // Only initial template contains {{GREETING}}, but Replace is safe either way.
        baseRules = baseRules.Replace("{{GREETING}}", greeting);

        // Provide caller phone context clearly.
        var callerContext = string.IsNullOrWhiteSpace(callerPhone)
            ? "SYSTEM DATA: CallerPhone is NOT available."
            : $"SYSTEM DATA: CallerPhone is available and is {callerPhone}.";

        var companyContext =
            $"You are answering for {companyCfg.CompanyName}. " +
            (string.IsNullOrWhiteSpace(companyCfg.ServiceArea)
                ? ""
                : $"Service area is {companyCfg.ServiceArea}. ");

        // Deterministic reservation lookup results.
        var reservationContext = reservationLookup.Found && reservationLookup.Snapshot != null
            ? "SYSTEM DATA: An active reservation WAS found for this caller. " +
              $"ReservationId={reservationLookup.Snapshot.ReservationId}; " +
              $"Status={reservationLookup.Snapshot.Status}; " +
              $"Pickup={reservationLookup.Snapshot.Pickup}; " +
              $"Dropoff={reservationLookup.Snapshot.Dropoff}; " +
              $"ScheduledTime={reservationLookup.Snapshot.ScheduledTime}."
            : "SYSTEM DATA: No active reservation was found for this caller (or lookup not available yet).";

        // Hard guardrail to prevent reservation hallucinations.
        var reservationGuardrail =
            "GUARDRAIL: You must treat the SYSTEM DATA above as the only source of truth for reservation existence/status. " +
            "If SYSTEM DATA says no active reservation was found, do NOT claim you found one.";

        return baseRules + " " + callerContext + " " + reservationContext + " " + reservationGuardrail + " " + companyContext;
    }

    static IResult GuardrailUnknownCompany(AgentMessageRequest request)
    {
        var extShown = string.IsNullOrWhiteSpace(request.Extension) ? "missing" : request.Extension;

        return Results.Ok(new
        {
            response =
                "Thanks for calling. I want to make sure I connect you to the right company. " +
                "Are you calling for Silver Cab of PG, Diamond Cab of Baltimore City, DC VIP Cab, " +
                "Diamond Cab of Anne Arundel County, or Transport DC?",
            routing = new
            {
                company = "Unknown",
                extension_received = extShown,
                caller_phone = request.CallerPhone,
            }
        });
    }

    // -------------------- Response Parsing (Responses API) --------------------

    public static class ResponseHelper
    {
        public static string? ExtractResponseText(string json)
        {
            try
            {
                using var doc = JsonDocument.Parse(json);

                if (!doc.RootElement.TryGetProperty("output", out var output) ||
                    output.ValueKind != JsonValueKind.Array)
                    return null;

                var sb = new StringBuilder();

                foreach (var item in output.EnumerateArray())
                {
                    if (!item.TryGetProperty("content", out var content) ||
                        content.ValueKind != JsonValueKind.Array)
                        continue;

                    foreach (var contentItem in content.EnumerateArray())
                    {
                        if (contentItem.TryGetProperty("type", out var type) &&
                            type.GetString() == "output_text" &&
                            contentItem.TryGetProperty("text", out var text))
                        {
                            sb.Append(text.GetString());
                        }
                    }
                }

                var result = sb.ToString();
                return string.IsNullOrWhiteSpace(result) ? null : result;
            }
            catch
            {
                return null;
            }
        }
    }
}
