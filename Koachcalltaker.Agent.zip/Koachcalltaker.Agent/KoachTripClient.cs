﻿using System.Text.Json;

namespace KoachCallTake;

/// <summary>
/// Trip-specific client for Koach Dispatch API.
/// Uses KoachApiService for authentication/JWT caching.
///
/// IMPORTANT:
/// - Reservation "get" endpoints are GET-only in your environment.
/// - This client returns a structured result and does NOT throw for expected failures.
/// - Authentication/JWT caching remains inside KoachApiService.
/// </summary>
public sealed class KoachTripClient
{
    private readonly KoachApiService _koachApi;

    public KoachTripClient(KoachApiService koachApi)
    {
        // Comment: KoachApiService owns JWT auth + caching.
        _koachApi = koachApi;
    }

    // -------------------- Result Types --------------------

    /// <summary>
    /// Result wrapper for reservation-status lookup by phone.
    /// RawJson is always retained for debugging until schema is finalized.
    /// </summary>
    public sealed class KoachLastReservationStatusResult
    {
        public bool Success { get; set; }

        // Comment: Correlation/debug info.
        public string TenantId { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;

        // Comment: Full raw response from Koach API.
        public string RawJson { get; set; } = string.Empty;

        // Comment: Best-effort extracted fields (optional).
        public string? ReservationId { get; set; }
        public string? Status { get; set; }
        public string? Pickup { get; set; }
        public string? Dropoff { get; set; }
        public string? ScheduledTime { get; set; }

        // Comment: Safe error message (no JWT, no password).
        public string? Error { get; set; }
    }

    // -------------------- API Calls --------------------

    /// <summary>
    /// Attempts to call Koach "last reservation status by phone" endpoint using GET only.
    ///
    /// Because exact routing may vary by deployment, this method tries a small
    /// deterministic set of endpoint paths and query parameter casings.
    ///
    /// Once you confirm the exact endpoint path and parameter names,
    /// we will remove the variants and keep only the correct one.
    /// </summary>
   
    // -------------------- Helpers --------------------

    /// <summary>
    /// Builds a URL-encoded query string from a dictionary.
    /// </summary>
    private static string BuildQueryString(Dictionary<string, string> query)
    {
        // Comment: Deterministic order helps debugging.
        var parts = new List<string>();

        foreach (var kvp in query.OrderBy(k => k.Key, StringComparer.Ordinal))
        {
            var k = Uri.EscapeDataString(kvp.Key);
            var v = Uri.EscapeDataString(kvp.Value ?? string.Empty);
            parts.Add($"{k}={v}");
        }

        return string.Join("&", parts);
    }
    public async Task<KoachLastReservationStatusResult> GetLastReservationStatusByPhoneAsync(
    string? baseUrl,
    string tenant,
    string username,
    string phone,
    CancellationToken ct = default)
    {
        // Comment: Normalize values so we never throw NullReferenceException.
        var safeTenant = tenant ?? string.Empty;
        var safePhone = phone ?? string.Empty;

        var result = new KoachLastReservationStatusResult
        {
            Success = false,
            TenantId = safeTenant,
            Phone = safePhone
        };

        if (string.IsNullOrWhiteSpace(safePhone))
        {
            result.Error = "Phone is missing/empty; lookup skipped.";
            return result;
        }

        // -------------------- Acquire authenticated client --------------------
        // Comment: Even if this endpoint didn't require auth before, we keep auth enabled
        // because your environment already proved JWT works and it may be required in production.
        HttpClient client;
        try
        {
            client = await _koachApi.CreateAuthedClientAsync(baseUrl, safeTenant, username, ct);
        }
        catch (Exception ex)
        {
            result.Error = $"JWT acquisition failed: {ex.Message}";
            return result;
        }

        // -------------------- Exact GET endpoint (confirmed by your API dev) --------------------
        // https://apicall.koachapp.com/Trip/GetLastReservationStatusByPhone?phone=240-714-4625
        //
        // IMPORTANT:
        // - No "/api" prefix.
        // - Query param name is lowercase: phone
        // - TenantId is NOT present in query.
        var encodedPhone = Uri.EscapeDataString(safePhone.Trim());
        var relativeUrl = $"Api/Trip/GetLastReservationStatusByPhone?phone={encodedPhone}";

        HttpResponseMessage resp;
        string body;

        try
        {
            resp = await client.GetAsync(relativeUrl, ct);
            body = await resp.Content.ReadAsStringAsync(ct);
        }
        catch (Exception ex)
        {
            result.Error = $"Koach API call failed (network/TLS/etc): {ex.Message}";
            return result;
        }

        if (!resp.IsSuccessStatusCode)
        {
            result.Error = $"Koach Trip lookup failed: {(int)resp.StatusCode} {resp.ReasonPhrase}. Body={body}";
            return result;
        }

        result.RawJson = body;
        result.Success = true;

        // Comment: Best-effort extraction (tolerant).
        TryExtractCommonReservationFields(body, result);

        return result;
    }

    /// <summary>
    /// Best-effort JSON parsing helper.
    /// We do not assume the schema is stable yet.
    /// </summary>
    private static void TryExtractCommonReservationFields(string rawJson, KoachLastReservationStatusResult result)
    {
        if (string.IsNullOrWhiteSpace(rawJson))
            return;

        try
        {
            using var doc = JsonDocument.Parse(rawJson);
            var root = doc.RootElement;

            // Comment: Sometimes responses are nested in "data" or "result".
            var obj = root;
            if (obj.ValueKind == JsonValueKind.Object)
            {
                if (obj.TryGetProperty("data", out var data) && data.ValueKind == JsonValueKind.Object)
                {
                    obj = data;
                }
                else if (obj.TryGetProperty("result", out var res) && res.ValueKind == JsonValueKind.Object)
                {
                    obj = res;
                }
            }

            // Comment: Try common property names.
            result.ReservationId = TryGetStringAny(obj, "RID", "rid", "Rid", "reservationId", "ReservationId");
            result.Status = TryGetStringAny(obj, "status", "Status", "reservationStatus", "ReservationStatus");
            result.Pickup = TryGetStringAny(obj, "pickup", "Pickup", "pickupAddress", "PickupAddress");
            result.Dropoff = TryGetStringAny(obj, "dropoff", "Dropoff", "dropoffAddress", "DropoffAddress");
            result.ScheduledTime = TryGetStringAny(obj, "time", "Time", "scheduledTime", "ScheduledTime");
        }
        catch
        {
            // Comment: Ignore parse errors; RawJson is still available.
        }
    }

    /// <summary>
    /// Attempts to read a string (or number) from one of several possible property names.
    /// Returns the first non-empty value found.
    /// </summary>
    private static string? TryGetStringAny(JsonElement obj, params string[] names)
    {
        if (obj.ValueKind != JsonValueKind.Object)
            return null;

        foreach (var name in names)
        {
            if (!obj.TryGetProperty(name, out var prop))
                continue;

            if (prop.ValueKind == JsonValueKind.String)
            {
                var s = prop.GetString();
                if (!string.IsNullOrWhiteSpace(s))
                    return s;
            }

            // Comment: Sometimes IDs might be numeric; attempt to convert.
            if (prop.ValueKind == JsonValueKind.Number)
            {
                var s = prop.ToString();
                if (!string.IsNullOrWhiteSpace(s))
                    return s;
            }
        }

        return null;
    }
}
